#pragma once
class ISum :public IUnknown
{
public:
	//ISum specific method declarations
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class ISubtract :public IUnknown
{
public:
	//ISubtract specific method declarations
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IMultiplication :public IUnknown
{
public:
	//IMultiplication specific method declarations
	virtual HRESULT __stdcall MultiplicationOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IDivision :public IUnknown
{
public:
	//IDivision specific method declarations
	virtual HRESULT __stdcall DivisionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of SumSubtract Component {D08AD690-1FCA-46FE-BA75-D664DFCBD7F5}
const CLSID CLSID_SumSubtract = { 0xd08ad690, 0x1fca, 0x46fe, 0xba, 0x75, 0xd6, 0x64, 0xdf, 0xcb, 0xd7, 0xf5 };

//IID of ISum Interface {57DA684D-8D45-404C-9349-0043D55708EC}
const IID IID_ISum = { 0x57da684d, 0x8d45, 0x404c, 0x93, 0x49, 0x0, 0x43, 0xd5, 0x57, 0x8, 0xec };

//IID of ISubtract Interface {F6C2585A-57EC-43DD-A346-ECD1E09794A1}
const IID IID_ISubtract = { 0xf6c2585a, 0x57ec, 0x43dd, 0xa3, 0x46, 0xec, 0xd1, 0xe0, 0x97, 0x94, 0xa1 };

//IID of IMultiplication Interface {22E1EFFF-BA24-46F4-A1E6-7A722352266C}
const IID IID_IMultiplication = { 0x22e1efff, 0xba24, 0x46f4, 0xa1, 0xe6, 0x7a, 0x72, 0x23, 0x52, 0x26, 0x6c };

//IID of IDivision Interface // {B26770AC-AE57-419E-899B-326C2CF5A788}
const  IID IID_IDivision = { 0xb26770ac, 0xae57, 0x419e, 0x89, 0x9b, 0x32, 0x6c, 0x2c, 0xf5, 0xa7, 0x88 };











