#pragma once

class ISum :public IUnknown
{
public:
	//ISum specific method declarations
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class ISubtract :public IUnknown
{
public:
	//ISubtract specific method declarations
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of SumSubtract Component {277F2414-3222-49E6-8ABB-487ABD206A60}
const CLSID CLSID_SumSubtract = { 0x277f2414, 0x3222, 0x49e6, 0x8a, 0xbb, 0x48, 0x7a, 0xbd, 0x20, 0x6a, 0x60 };

//IID of ISum Interface {5EE29941-B8E8-495A-BF30-3976BFE56D14}
const IID IID_ISum = { 0x5ee29941, 0xb8e8, 0x495a, 0xbf, 0x30, 0x39, 0x76, 0xbf, 0xe5, 0x6d, 0x14 };

//IID of ISubtract Interface {3C8ACB8C-13CC-48CB-BD32-E7D8B733D07F}
const IID IID_ISubtract = { 0x3c8acb8c, 0x13cc, 0x48cb, 0xbd, 0x32, 0xe7, 0xd8, 0xb7, 0x33, 0xd0, 0x7f };




