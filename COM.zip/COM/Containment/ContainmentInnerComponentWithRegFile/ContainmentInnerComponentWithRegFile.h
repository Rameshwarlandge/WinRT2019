#pragma once
class IMultiplication: public IUnknown
{
public:
	//IMultiplication specific method declarations
	virtual HRESULT __stdcall MultiplicationOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IDivision : public IUnknown
{
public:
	//IDivision specific method declarations
	virtual HRESULT __stdcall DivisionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of MultiplicationDivision Component // {8C38ECB4-55EB-47E7-AAB4-D5F9A1160C37}
const CLSID CLSID_MultiplicationDivision = { 0x8c38ecb4, 0x55eb, 0x47e7, 0xaa, 0xb4, 0xd5, 0xf9, 0xa1, 0x16, 0xc, 0x37 };

//IID of IMultiplication Interface
const IID IID_IMultiplication = { 0x22e1efff, 0xba24, 0x46f4, 0xa1, 0xe6, 0x7a, 0x72, 0x23, 0x52, 0x26, 0x6c };

//IID of IDivision Interface
const  IID IID_IDivision = { 0xb26770ac, 0xae57, 0x419e, 0x89, 0x9b, 0x32, 0x6c, 0x2c, 0xf5, 0xa7, 0x88 };

