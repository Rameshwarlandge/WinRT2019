#pragma once
class ISum :public IUnknown
{
public:
	//ISum specific method declarations
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class ISubtract :public IUnknown
{
public:
	//ISubtract specific method declarations
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IMultiplication :public IUnknown
{
public:
	//IMultiplication specific method declarations
	virtual HRESULT __stdcall MultiplicationOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IDivision :public IUnknown
{
public:
	//IDivision specific method declarations
	virtual HRESULT __stdcall DivisionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of SumSubtract component {2F1A07C8-E291-46DE-84DF-6A6B7304D738}
const CLSID CLSID_SumSubtract = { 0x2f1a07c8, 0xe291, 0x46de, 0x84, 0xdf, 0x6a, 0x6b, 0x73, 0x4, 0xd7, 0x38 };

//IID of ISum Interface {9E1C2607-6D4A-4E65-A842-350F658F8530}
const IID IID_ISum = { 0x9e1c2607, 0x6d4a, 0x4e65, 0xa8, 0x42, 0x35, 0xf, 0x65, 0x8f, 0x85, 0x30 };

//IID of ISubtract Interface {3649CB2D-F67F-42DC-9A07-54EBAB441758}
const IID IID_ISubtract = { 0x3649cb2d, 0xf67f, 0x42dc, 0x9a, 0x7, 0x54, 0xeb, 0xab, 0x44, 0x17, 0x58 };

//CLSID of MultiplicationDivision Component {C7FBA1C1-2E3D-4FE6-8A69-38CB11805AE7}
const CLSID CLSID_MultiplicationDivision = { 0xc7fba1c1, 0x2e3d, 0x4fe6, 0x8a, 0x69, 0x38, 0xcb, 0x11, 0x80, 0x5a, 0xe7 };

//IID of IMultiplication Interface {6AC98A79-5FAD-4CC9-830E-0FB17BA3460C}
const IID IID_IMultiplication = { 0x6ac98a79, 0x5fad, 0x4cc9, 0x83, 0xe, 0xf, 0xb1, 0x7b, 0xa3, 0x46, 0xc };

//IID of IDivision Interface {B72FE922-2C1C-4AB7-8A9D-736DEF707333}
const IID IID_IDivision = { 0xb72fe922, 0x2c1c, 0x4ab7, 0x8a, 0x9d, 0x73, 0x6d, 0xef, 0x70, 0x73, 0x33 };



