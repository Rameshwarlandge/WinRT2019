#pragma once
class ISum :public IUnknown
{
public:
	//ISum specific method declarations
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
};
class ISubtract :public IUnknown
{
public:
	//ISubtract specific method declarations
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of SumSubtract component {2F1A07C8-E291-46DE-84DF-6A6B7304D738}
const CLSID CLSID_SumSubtract = { 0x2f1a07c8, 0xe291, 0x46de, 0x84, 0xdf, 0x6a, 0x6b, 0x73, 0x4, 0xd7, 0x38 };

//IID of ISum Interface {9E1C2607-6D4A-4E65-A842-350F658F8530}
const IID IID_ISum = { 0x9e1c2607, 0x6d4a, 0x4e65, 0xa8, 0x42, 0x35, 0xf, 0x65, 0x8f, 0x85, 0x30 };

//IID of ISubtract Interface {3649CB2D-F67F-42DC-9A07-54EBAB441758}
const IID IID_ISubtract = { 0x3649cb2d, 0xf67f, 0x42dc, 0x9a, 0x7, 0x54, 0xeb, 0xab, 0x44, 0x17, 0x58 };


