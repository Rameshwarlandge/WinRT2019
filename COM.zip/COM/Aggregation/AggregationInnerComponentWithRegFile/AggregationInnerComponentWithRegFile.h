#pragma once
class IMultiplication :public IUnknown
{
public:
	//IMultiplication specific method declarations
	virtual HRESULT __stdcall MultiplicationOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class IDivision :public IUnknown
{
public:
	//IDivision specific method declarations
	virtual HRESULT __stdcall DivisionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of MultiplicationDivision Component {C7FBA1C1-2E3D-4FE6-8A69-38CB11805AE7}
const CLSID CLSID_MultiplicationDivision = { 0xc7fba1c1, 0x2e3d, 0x4fe6, 0x8a, 0x69, 0x38, 0xcb, 0x11, 0x80, 0x5a, 0xe7 };

//IID of IMultiplication Interface {6AC98A79-5FAD-4CC9-830E-0FB17BA3460C}
const IID IID_IMultiplication = { 0x6ac98a79, 0x5fad, 0x4cc9, 0x83, 0xe, 0xf, 0xb1, 0x7b, 0xa3, 0x46, 0xc };

//IID of IDivision Interface {B72FE922-2C1C-4AB7-8A9D-736DEF707333}
const IID IID_IDivision = { 0xb72fe922, 0x2c1c, 0x4ab7, 0x8a, 0x9d, 0x73, 0x6d, 0xef, 0x70, 0x73, 0x33 };



