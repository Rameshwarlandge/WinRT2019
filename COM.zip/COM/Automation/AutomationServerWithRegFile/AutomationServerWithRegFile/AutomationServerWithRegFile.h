#pragma once
class IMyMath : public IDispatch
{
public:
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};
//CLSID of MyMath Component : {A6E111C3-750E-495A-A114-88D50F980509}
const CLSID CLSID_MyMath = { 0xa6e111c3, 0x750e, 0x495a, 0xa1, 0x14, 0x88, 0xd5, 0xf, 0x98, 0x5, 0x9 };
//IID of IID_IMyMath : {ECC9E641-13E8-4EA6-BFB1-03441E087C4D}
const IID IID_IMyMath = { 0xecc9e641, 0x13e8, 0x4ea6, 0xbf, 0xb1, 0x3, 0x44, 0x1e, 0x8, 0x7c, 0x4d };

