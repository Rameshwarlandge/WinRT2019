#pragma once
class ISum:public IUnknown
{
public:
	//ISum specific declarations
	virtual HRESULT __stdcall SumOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

class ISubtract:public IUnknown
{
public:
	//ISubtract specific method declarations
	virtual HRESULT __stdcall SubtractionOfTwoIntegers(int, int, int *) = 0; //pure virtual
};

//CLSID of SumSubtract Component {52D7A148-D595-4FCD-BA6D-F0452672DA44}
const CLSID CLSID_SumSubtract = { 0x52d7a148, 0xd595, 0x4fcd, 0xba, 0x6d, 0xf0, 0x45, 0x26, 0x72, 0xda, 0x44 };

//IID of ISum Interface {DC0E3153-B33C-4DB3-93EB-2153AA95054F}
const IID IID_ISum = { 0xdc0e3153, 0xb33c, 0x4db3, 0x93, 0xeb, 0x21, 0x53, 0xaa, 0x95, 0x5, 0x4f };

//IID of ISubtract Interface {DB469963-749F-4DBE-8977-DB724577C6FE}
const IID IID_ISubtract = { 0xdb469963, 0x749f, 0x4dbe, 0x89, 0x77, 0xdb, 0x72, 0x45, 0x77, 0xc6, 0xfe };



